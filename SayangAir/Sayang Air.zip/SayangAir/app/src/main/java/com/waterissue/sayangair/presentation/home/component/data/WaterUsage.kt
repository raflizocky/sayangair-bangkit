package com.waterissue.sayangair.presentation.home.component.data

data class WaterUsage(
    val months: Map<String, WaterDetails>
) {

}