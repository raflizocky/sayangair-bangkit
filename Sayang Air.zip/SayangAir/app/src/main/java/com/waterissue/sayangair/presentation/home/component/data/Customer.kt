package com.waterissue.sayangair.presentation.home.component.data

data class Customer(
    val customerId: Int,
    val name: String
)