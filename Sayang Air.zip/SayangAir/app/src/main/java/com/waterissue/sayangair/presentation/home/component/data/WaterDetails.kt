package com.waterissue.sayangair.presentation.home.component.data

data class WaterDetails(
    val bill: Int,
    val fine: Int,
    val waterCubic: Int
)